
<?php
/**
 * Plugin Name: Custom Authentication Plugin
 * Description: A plugin for user login, registration with multi-relationship, and 2FA.
 * Version: 1.0
 * Author: Advance I-Tech
 * 
 */
if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}
function custom_auth_shortcode() {
    ob_start();
    ?>
    <div id="custom-auth-button">
        <button onclick="openAuthModal()">Customer Login</button>
    </div>

    <div id="custom-auth-modal" class="auth-modal">
        <div class="auth-modal-content">
            <span class="auth-close" onclick="closeAuthModal()">&times;</span>
            
            <!-- Login Form -->
            <div id="login-section">
                <h2>Customer Login</h2>
                <form method="post">
                    <label for="username">Username</label>
                    <input type="text" name="username" required>

                    <label for="password">Password</label>
                    <input type="password" name="password" required>

                    <input type="submit" name="login_user" value="Login">
                </form>

                <div id="otp-section" style="display: none;">
                    <h3>Enter OTP</h3>
                    <form method="post">
                        <input type="text" name="otp" required>
                        <input type="submit" name="verify_otp" value="Verify OTP">
                    </form>
                </div>

                <p>Don't have an account? <a href="#" onclick="showRegistration()">Register Here</a></p>
            </div>

            <!-- Registration Form -->
            <div id="registration-section" style="display: none;">
                <h2>Register</h2>
                <form method="post">
                    <label for="username">Username</label>
                    <input type="text" name="username" required>

                    <label for="email">Email</label>
                    <input type="email" name="email" required>

                    <label for="password">Password</label>
                    <input type="password" name="password" required>

                    <label for="relationship">Relationship</label>
                    <select name="relationship">
                        <option value="parent">Parent</option>
                        <option value="child">Child</option>
                        <option value="guardian">Guardian</option>
                    </select>

                    <input type="submit" name="register_user" value="Register">
                </form>

                <p>Already have an account? <a href="#" onclick="showLogin()">Login Here</a></p>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('custom_auth', 'custom_auth_shortcode');
