<?php return array('dependencies' => array(), 'version' => 'e78d65f4c12a29fb3a94');
